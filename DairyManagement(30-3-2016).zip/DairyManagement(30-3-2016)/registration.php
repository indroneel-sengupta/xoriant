
<html>
<body>
	<?php

		$servername = "localhost";
		$username = "it13061mysql";
		$password = "indroneel";
		$dbName = "it13061";


		$fname = $_POST['firstName'];
		$lname = $_POST['lastName'];
		$gen = $_POST['gender'];
		$email = $_POST['email'];
		$cnum = $_POST['contactNumber'];
		$un = $_POST['setUsername'];
		$pw = $_POST['setPassword'];
		// Create connection
		$conn = new mysqli($servername, $username, $password,$dbName);
		// Check connection
		if ($conn->connect_error) {
    			die("Connection failed: " . $conn->connect_error);
		}
		$sql = "INSERT INTO registration(FirstName, LastName,Gender,Email,ContactNumber,Address,Username,Password) VALUES ('$fname','$lname','$gen','$email',$cnum,'$un','$pw' )";

		if ($conn->query($sql) === TRUE) {
    			echo "New record created successfully";
		} else {
    			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	?>
	
</body>
</html> 
